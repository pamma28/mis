<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['rc']= Array(
     'period' => '2015',
     'price' => '125000',
     'no_atm' => '999999',
     'an_atm' => 'Student English Forum',
     'jns_atm' => 'Mandiri',
     'quota' => '200',
     'begin' => '2015/06/19',
     'expired' => '2015/08/20',
     'cp' => '085612312',
     'bbm' => 'fsaf1a',
     'email' => 'education@sefunsoed.org'
  ); 
  
$config['a'] = '';
