<div class="modal-header">
   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
   <h4><i class="fa fa-flag"></i> Read Notification</h4>
</div>
<div class="modal-body">
	<?=$rdata;?>
	
</div>
<div class="clearfix"></div>
<div class="modal-footer">
	<a class="btn btn-default btn-ok" data-dismiss="modal">Close</a>
</div>
