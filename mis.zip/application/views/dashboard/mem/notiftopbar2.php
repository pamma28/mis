<?php if ($totnotif>0) { ?><span class="label label-danger ">
		<?=$totnotif;?></span><?php } ?>