<!-- Content Header (Page header) -->
<section class="content-header">
	
	<h1><i class="fa fa-bell fa-lg"></i> Notification <small>list</small></h1>
		<ol class="breadcrumb">
            <?=set_breadcrumb();?>
		</ol>
</section>

<!-- Main content -->
<section class="content">
	<div class="box">
		<div class="box-header">
			
		
		</div>
		<div class="box-body table-responsive">
		<table class="table table-striped">
			<?=$listdata;?>
		</table>
		</div>
	</div>
		
		
	
	
	<script type="text/javascript">
	
	
	</script>
</section>