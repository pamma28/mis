<?php 
if (!defined('BASEPATH')) exit('No direct script access allowed');  
 
require_once APPPATH."/third_party/atrigger/ATrigger.php";

//ATrigger::init("YOUR_APIKey","YOUR_APISecret");
ATrigger::init("5048410639605220993","WUz5Hc7fboRe36XlE57nCs2aBdTJ26");
class Cronjob {
	public function __construct() {
        parent::__construct();
		
    }
    

    public function startcron(){

   		
    }

}

?>