<?php 
if (!defined('BASEPATH')) exit('No direct script access allowed');  
 
require_once APPPATH."/third_party/flourish/fException.php";
require_once APPPATH."/third_party/flourish/fUnexpectedException.php";
require_once APPPATH."/third_party/flourish/fConnectivityException.php";
require_once APPPATH."/third_party/flourish/fExpectedException.php";
require_once APPPATH."/third_party/flourish/fValidationException.php";
require_once APPPATH."/third_party/flourish/fEmail.php";
require_once APPPATH."/third_party/flourish/fCore.php";
require_once APPPATH."/third_party/flourish/fProgrammerException.php";
require_once APPPATH."/third_party/flourish/fMailbox.php";
 
class Mailreader {
   
}