<?php

$lang['set_home'] = 'Home';

/* End of file breadcrumb_lang.php */
/* Location: ./application/language/english/breadcrumb_lang.php */
